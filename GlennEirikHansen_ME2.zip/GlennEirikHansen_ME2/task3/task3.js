
var i = 10;
for(var i = 0; i < 3; i++){
    if(i == 2){
        let i = 5;
    }
}
alert(i); // Will return the number 3